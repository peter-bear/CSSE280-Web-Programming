var rhit = rhit || {};

rhit.FB_COLLECTION_SPELLS = "Spells";
rhit.FB_KEY_NAME = "quote";
rhit.FB_KEY_DESCRIPTION = "description";
rhit.FB_KEY_RANK = "rank";
rhit.fbSpellsCollectionManager = null;

// From: https://stackoverflow.com/questions/494143/creating-a-new-dom-element-from-an-html-string-using-built-in-dom-methods-or-pro/35385518#35385518
function htmlToElement(html) {
	var template = document.createElement('template');
	html = html.trim();
	template.innerHTML = html;
	return template.content.firstChild;
}

rhit.ListPageController = class {
	constructor() {

	}


	updateList() {

	}
}

rhit.Spell = class {
	constructor(id, name, description, rank) {
		this.id = id;
		this.name = name;
		this.description = description;
		this.rank = rank;
	}
}

rhit.FbSpellsCollectionManager = class {
	constructor() {
		this._documentSnapshots = [];
		this._ref = firebase.firestore().collection(rhit.FB_COLLECTION_SPELLS);
		this._unsubscribe = null;
	}

	add(name, description, rank) {
		// Add a new document with a generated id.
	}

	beginListening(changeListener) {
	}

	stopListening() {
	}

	delete(documentIdToDelete) {
		// Delete the document that has this document id.
	}

	// Other methods as needed.
}


/* Main */
rhit.main = function () {
	console.log("Ready");
	if (document.querySelector("#listPage")) {
		console.log("You are on the list page. Do stuff!");
	}
};

rhit.main();
